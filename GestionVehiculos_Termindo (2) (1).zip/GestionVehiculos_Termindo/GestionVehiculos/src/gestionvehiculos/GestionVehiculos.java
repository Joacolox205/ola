
package gestionvehiculos;

import controlador.ControladorVehiculo;
import modelo.VehiculoDAO;
import vista.VistaVehiculos;


public class GestionVehiculos {

    public static void main(String[] args) {
        
        // hacer
        VistaVehiculos vista = new VistaVehiculos();
        VehiculoDAO dao = new VehiculoDAO();
        
        ControladorVehiculo controlador = new ControladorVehiculo(vista, dao);
        
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        
        
    }
    
}
