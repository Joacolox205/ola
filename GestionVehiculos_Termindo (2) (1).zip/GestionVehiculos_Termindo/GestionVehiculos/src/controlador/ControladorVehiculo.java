package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Vehiculo;
import modelo.VehiculoDAO;
import vista.VistaVehiculos;

public class ControladorVehiculo implements ActionListener{

    private VistaVehiculos vista;
    private VehiculoDAO vehiculoDAO;

    public ControladorVehiculo(VistaVehiculos vista, VehiculoDAO vehiculoDAO) {
        this.vista = vista;
        this.vehiculoDAO = vehiculoDAO;

        this.vista.getBtnGuardar().addActionListener(this);
        this.vista.getBtnReload().addActionListener(this);

        // 🔥 NUEVOS BOTONES
        this.vista.getBtnEliminar().addActionListener(this);
        this.vista.getBtnActualizarKm().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == vista.getBtnGuardar()) {
            guardarVehiculo();

        } else if (e.getSource() == vista.getBtnReload()) {
            cargarTabla();

        } else if (e.getSource() == vista.getBtnEliminar()) {
            eliminarVehiculo();

        } else if (e.getSource() == vista.getBtnActualizarKm()) {
            actualizarKilometraje();
        }
    }
    
    
    public void guardarVehiculo(){
        try{
            Vehiculo vehiculo = new Vehiculo(
                vista.getTxtPatente().getText(),
                vista.getTxtMarca().getText(),
                vista.getTxtModelo().getText(),
                Integer.parseInt(vista.getTxtAnio().getText()),
                Integer.parseInt(vista.getTxtKilometraje().getText())
            );
            vehiculoDAO.insertar(vehiculo);
            cargarTabla();
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Error al guardar.");
        }
    }
    
    
    public void cargarTabla(){
        DefaultTableModel model = vista.getModeloTabla();
        model.setRowCount(0);

        List<Vehiculo> lista = vehiculoDAO.leer();

        for(Vehiculo v : lista){
            model.addRow(new Object[]{
                v.getPatente(),
                v.getMarca(),
                v.getModelo(),
                v.getAnio(),
                v.getKilometraje()
            });
        }
    }
    
    
    // 🔥 NUEVO — ELIMINAR POR PATENTE
    public void eliminarVehiculo(){
        String patente = vista.getTxtPatente().getText();
        
        if(vehiculoDAO.eliminar(patente)){
            JOptionPane.showMessageDialog(null, "Vehículo eliminado");
            cargarTabla();
        } else {
            JOptionPane.showMessageDialog(null, "No existe un vehículo con esa patente");
        }
    }
    
    
    // 🔥 NUEVO — ACTUALIZAR KM POR PATENTE
    public void actualizarKilometraje(){
        String patente = vista.getTxtPatente().getText();
        int nuevoKm = Integer.parseInt(vista.getTxtKilometraje().getText());
        
        if(vehiculoDAO.actualizarKilometraje(patente, nuevoKm)){
            JOptionPane.showMessageDialog(null, "Kilometraje actualizado");
            cargarTabla();
        } else {
            JOptionPane.showMessageDialog(null, "No existe vehículo con esa patente");
        }
    }
}
