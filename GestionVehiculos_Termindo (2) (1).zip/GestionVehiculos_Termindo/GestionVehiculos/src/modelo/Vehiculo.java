
package modelo;

public class Vehiculo {
    private String patente;
    private String modelo;
    private String marca;
    private int anio;
    private int kilometraje;

    public Vehiculo(String patente, String modelo, String marca, int anio, int kilometraje) {
        this.patente = patente;
        this.modelo = modelo;
        this.marca = marca;
        this.anio = anio;
        this.kilometraje = kilometraje;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public int getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }
    
    
}
