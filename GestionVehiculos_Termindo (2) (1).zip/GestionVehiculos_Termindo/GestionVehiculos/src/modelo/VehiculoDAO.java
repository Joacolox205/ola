package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehiculoDAO {
    private Conexion conexion = new Conexion();
    
    public void insertar(Vehiculo vehiculo){
        String sentencia = "INSERT INTO vehiculos VALUES(?,?,?,?,?)";
    
        try{
            Connection con = conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sentencia);
        
            ps.setString(1, vehiculo.getPatente());
            ps.setString(2, vehiculo.getMarca());
            ps.setString(3, vehiculo.getModelo());
            ps.setInt(4, vehiculo.getAnio());
            ps.setInt(5, vehiculo.getKilometraje());

            ps.executeUpdate();
            System.out.println("Vehiculo insertado");
            
        }catch(Exception error){
            System.out.println("Error insertar: " + error.getMessage());
        }
    }
    
    
    public List<Vehiculo> leer(){
        String sentencia = "SELECT * FROM vehiculos";
        List<Vehiculo> listaVehiculos = new ArrayList<>();
        try{
            Connection con = conexion.getConexion();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sentencia);
            
            while(rs.next()){
                Vehiculo v = new Vehiculo(
                    rs.getString("patente"),
                    rs.getString("marca"),
                    rs.getString("modelo"),
                    rs.getInt("anio"),
                    rs.getInt("kilometraje")
                );
                listaVehiculos.add(v);
            }
        }catch (Exception error){
            System.out.println("Error leer: " + error.getMessage());
        }
        return listaVehiculos;
    }
    
    
    // 🔥 NUEVO — DELETE POR PATENTE
    public boolean eliminar(String patente){
        String sql = "DELETE FROM vehiculos WHERE patente = ?";
        
        try{
            Connection con = conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, patente);
            
            int filas = ps.executeUpdate();
            return filas > 0;
            
        }catch(Exception e){
            System.out.println("Error eliminar: " + e.getMessage());
            return false;
        }
    }
    
    
    // 🔥 NUEVO — UPDATE KILOMETRAJE POR PATENTE
    public boolean actualizarKilometraje(String patente, int nuevoKm){
        String sql = "UPDATE vehiculos SET kilometraje = ? WHERE patente = ?";
        
        try{
            Connection con = conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, nuevoKm);
            ps.setString(2, patente);
            
            int filas = ps.executeUpdate();
            return filas > 0;
            
        }catch(Exception e){
            System.out.println("Error actualizar: " + e.getMessage());
            return false;
        }
    }
}
