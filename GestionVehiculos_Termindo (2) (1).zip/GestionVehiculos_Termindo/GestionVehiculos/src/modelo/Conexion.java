

package modelo;
//IMPORTACIONES DESDE LA LIBRERIA AGREGADA
import java.sql.Connection;
import java.sql.DriverManager;


public class Conexion {
    private String URL = "jdbc:mysql://localhost:3306/gestionvehiculos";
    private String USER = "root";
    private String PASSWORD = "";
    
    public Connection getConexion(){
        Connection conexion = null;
        try{
            conexion = DriverManager.getConnection(URL,USER,PASSWORD);
            System.out.println("Conectado a la base de datos");
        }catch(Exception error){
            System.out.println("Error al conectarse: " + error.getMessage());
        }
        return conexion;
    }
    
    
}
