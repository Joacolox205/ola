package Vista;

import Controlador.ControladorCliente;
import Modelo.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaCliente extends JFrame {

    // --- 1. Declaración de Componentes ---
    private JLabel lblRut, lblNombres, lblApellidos, lblTelefono, lblCorreo;
    private JTextField txtRut, txtNombres, txtApellidos, txtTelefono, txtCorreo;
    private JButton btnGuardar, btnEliminar, btnLimpiar;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollPane;

    // Conectamos con tu Controlador existente
    // (Asegúrate de que ControladorCliente tenga constructor vacío o ajústalo)
    private ControladorCliente controlador = new ControladorCliente();

    // --- 2. Constructor de la Ventana ---
    public VistaCliente() {
        setTitle("Gestión de Clientes (Sin GUI Builder)");
        setSize(650, 550); // Tamaño: Ancho x Alto
        setLayout(null);   // Diseño manual (coordenadas x,y)
        setLocationRelativeTo(null); // Centrar en pantalla
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        iniciarComponentes();
        cargarTabla(); // Cargar datos al iniciar
    }

    private void iniciarComponentes() {
        // --- ETIQUETAS (LABELS) ---
        // Coordenadas: x (horizontal), y (vertical), ancho, alto
        
        lblRut = new JLabel("RUT:");
        lblRut.setBounds(30, 30, 80, 25);
        add(lblRut);

        lblNombres = new JLabel("Nombres:");
        lblNombres.setBounds(30, 70, 80, 25);
        add(lblNombres);

        lblApellidos = new JLabel("Apellidos:");
        lblApellidos.setBounds(30, 110, 80, 25);
        add(lblApellidos);

        lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(30, 150, 80, 25);
        add(lblTelefono);
        
        lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(30, 190, 80, 25);
        add(lblCorreo);

        // --- CAJAS DE TEXTO (TEXTFIELDS) ---
        txtRut = new JTextField();
        txtRut.setBounds(110, 30, 150, 25);
        add(txtRut);

        txtNombres = new JTextField();
        txtNombres.setBounds(110, 70, 200, 25);
        add(txtNombres);

        txtApellidos = new JTextField();
        txtApellidos.setBounds(110, 110, 200, 25);
        add(txtApellidos);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(110, 150, 150, 25);
        add(txtTelefono);
        
        txtCorreo = new JTextField();
        txtCorreo.setBounds(110, 190, 200, 25);
        add(txtCorreo);

        // --- BOTONES ---
        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(350, 30, 120, 40);
        add(btnGuardar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(350, 80, 120, 40);
        add(btnEliminar);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(350, 130, 120, 40);
        add(btnLimpiar);

        // --- TABLA ---
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("RUT");
        modeloTabla.addColumn("Nombres");
        modeloTabla.addColumn("Apellidos");
        modeloTabla.addColumn("Teléfono");
        modeloTabla.addColumn("Correo");

        tabla = new JTable(modeloTabla);
        scrollPane = new JScrollPane(tabla);
        scrollPane.setBounds(30, 250, 580, 230); // Posición de la tabla
        add(scrollPane);

        // --- ACCIONES DE LOS BOTONES ---
        
        // Acción Guardar
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                accionGuardar();
            }
        });

        // Acción Eliminar
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                accionEliminar();
            }
        });
        
        // Acción Limpiar
        btnLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });
    }

    // --- LÓGICA PRIVADA ---

    private void accionGuardar() {
        try {
            String rut = txtRut.getText();
            String nom = txtNombres.getText();
            String ape = txtApellidos.getText();
            String tel = txtTelefono.getText(); // Lo tratamos como String para facilitar
            String cor = txtCorreo.getText();

            if (rut.isEmpty() || nom.isEmpty()) {
                JOptionPane.showMessageDialog(this, "RUT y Nombre son obligatorios");
                return;
            }

            // Llamamos al método de tu Controlador
            // OJO: Asegúrate que tu controlador acepte estos 5 Strings
            boolean guardado = controlador.registrarCliente(rut, nom, ape, tel, cor);

            if (guardado) {
                JOptionPane.showMessageDialog(this, "Cliente Guardado con Éxito");
                cargarTabla();
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Error: El RUT ya existe");
            }
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage());
        }
    }

    private void accionEliminar() {
        String rut = txtRut.getText();
        if (rut.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escribe el RUT para eliminar");
            return;
        }

        boolean eliminado = controlador.eliminarCliente(rut);
        
        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Cliente Eliminado");
            cargarTabla();
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "RUT no encontrado");
        }
    }

    private void cargarTabla() {
        modeloTabla.setRowCount(0); // Limpiar visualmente la tabla
        
        // Obtenemos la lista desde el controlador
        for (Cliente c : controlador.obtenerCliente()) {
            Object[] fila = {
                c.getRut(), 
                c.getNombres(), 
                c.getApellidos(), 
                c.getTelefono(), 
                // Si en tu modelo Cliente el getter es getCorreo() úsalo, 
                // si es getCorreoElectronico() usa ese. Aquí pongo el más común:
                c.getCorreo() 
            };
            modeloTabla.addRow(fila);
        }
    }

    private void limpiarCampos() {
        txtRut.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
    }
}
