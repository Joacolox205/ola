package Repositorio;

import Modelo.Cliente;
import java.util.ArrayList;

public class RepositerioCliente {
    
    // Lista estática (Memoria RAM)
    private static ArrayList<Cliente> listaCliente = new ArrayList<>();

    public RepositerioCliente() {
    }
    
    // Método para agregar
    public void ingresarCliente(Cliente clien){
        listaCliente.add(clien);
    }
    
    // Método para listar
    public ArrayList<Cliente> listar(){
        return listaCliente;
    }
    
    // --- ESTOS SON LOS MÉTODOS QUE TE FALTABAN ---
    
    // 1. Método BUSCAR (Para saber si existe o para eliminarlo)
    public Cliente buscar(String rut) {
        for (Cliente c : listaCliente) {
            if (c.getRut().equalsIgnoreCase(rut)) {
                return c;
            }
        }
        return null; // No se encontró
    }
    
    // 2. Método ELIMINAR
    public boolean eliminar(String rut) {
        Cliente c = buscar(rut); // Usamos el método de arriba
        if (c != null) {
            listaCliente.remove(c);
            return true; // Se eliminó
        }
        return false; // No existía
    }
}
