package Repositorio;

import Modelo.Vehiculo;
import java.util.ArrayList;

public class RepositorioVehiculo {
    
    // 'static' es el truco para que los vehículos no se borren mientras usas la app
    private static ArrayList<Vehiculo> listaVehiculos = new ArrayList<>();

    public RepositorioVehiculo() {
    }
    
    // Guardar un vehículo en la lista
    public void guardar(Vehiculo v){
        listaVehiculos.add(v);
    }
    
    // Devolver todos los vehículos
    public ArrayList<Vehiculo> listar(){
        return listaVehiculos;
    }
    
    // Buscar por Patente (Necesario para validar repetidos o eliminar)
    public Vehiculo buscar(String patente){
        for(Vehiculo v : listaVehiculos){
            // Asumo que tu clase Vehiculo tiene un método getPatente()
            if(v.getPatente().equalsIgnoreCase(patente)){
                return v;
            }
        }
        return null; // No lo encontró
    }
    
    // Eliminar vehículo
    public boolean eliminar(String patente){
        Vehiculo v = buscar(patente);
        if(v != null){
            listaVehiculos.remove(v);
            return true;
        }
        return false;
    }
}