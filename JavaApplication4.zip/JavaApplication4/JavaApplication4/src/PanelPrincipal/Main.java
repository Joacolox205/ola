package PanelPrincipal;

import Vista.VistaCliente; // Importamos la nueva clase

public class Main {

    public static void main(String[] args) {
        // Instanciamos la ventana hecha a mano
        VistaCliente ventana = new VistaCliente();
        ventana.setVisible(true);
    }
    
}