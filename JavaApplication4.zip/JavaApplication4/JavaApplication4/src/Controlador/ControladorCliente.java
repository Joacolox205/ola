package Controlador;

import Modelo.Cliente;
import Repositorio.RepositerioCliente; // Ojo: Mantenemos tu nombre "Repositerio"
import java.util.ArrayList;

public class ControladorCliente {
    
    private RepositerioCliente repoClin;

    public ControladorCliente() {
        repoClin = new RepositerioCliente();
    }
    
    // CAMBIO IMPORTANTE: Ahora devuelve 'boolean' (true/false)
    public boolean registrarCliente(String rut, String nom, String ape, String tel, String cor){
        // 1. Verificamos si ya existe
        if (repoClin.buscar(rut) == null) {
            // 2. Si no existe, lo guardamos
            Cliente c = new Cliente(rut, nom, ape, tel, cor);
            repoClin.ingresarCliente(c);
            return true; // ¡Éxito!
        }
        // 3. Si ya existía, devolvemos falso
        return false;
    }
    
    public ArrayList<Cliente> obtenerCliente(){
        return repoClin.listar();
    }
    
    public boolean eliminarCliente(String rut) {
        return repoClin.eliminar(rut);
    }
}