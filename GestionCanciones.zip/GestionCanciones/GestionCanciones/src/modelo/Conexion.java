package modelo;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    
    
    private String URL = "jdbc:mysql://localhost:3306/Cancion"; 
    private String USER = "root";
    private String PASSWORD = "";
    
    public Connection getConexion() {
        Connection conexion = null;
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a Cancion");
            
        } catch (Exception error) {
            System.out.println("Error en la Conexión: " + error.getMessage());
        }
        return conexion;
    }
}
