package modelo;

public class Cantante {
    private int ID; 
    private String nombre;
    private int Calificacion;
    private int Fecha;

    
    public Cantante() {
    }

    
    public Cantante(String nombre, int Calificacion, int Fecha) {
        this.nombre = nombre;
        this.Fecha = Fecha;
        this.ID = ID;
    }

    
    public Cantante(int id, String nombre, int Calificacion, int Fecha) {
        
        this.nombre = nombre;
         this.Fecha = Fecha;
        this.ID = ID;
    }

    // Getters y Setters
    public int getId() { return ID; }
    public void setId(int ID) { this.ID = ID; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getCalificacion() { return Calificacion; }
    public void setCalificacion(int Calificacion) { this.Calificacion = Calificacion; }
    public int getFecha() { return Fecha; }
    public void setFecha(int Fecha) { this.Fecha = Fecha; }
}
