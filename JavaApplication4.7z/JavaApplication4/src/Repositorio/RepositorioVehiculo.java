
package Repositorio;

import Modelo.Vehiculo;
import Modelo.Automoviles;
import Modelo.Camionetas;
import java.util.ArrayList;


public class RepositorioVehiculo {
    
    private ArrayList<Vehiculo> listaVehiculo;
    
    public RepositorioVehiculo(){
        listaVehiculo = new ArrayList<Vehiculo>();
    }
    
    public void almacenAutomovil(Automoviles automovil){
        listaVehiculo = automovil.setPatente(patente);
        listaVehiculo.add(HVDF10, Toyota, Corolla, 50.000, Convencional, NO);
        listaVehiculo.add();
        listaVehiculo.add();
    }
    
    public void ingresarCliente(Camionetas comion){
        listaVehiculo.add();
    }
    
    
    
    
    
    
    
    
}
