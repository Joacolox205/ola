
package Repositorio;

import Modelo.Cliente;
import java.util.ArrayList;

public class RepositerioCliente {
    
    private ArrayList<Cliente> listaCliente;

    public RepositerioCliente() {
        listaCliente = new ArrayList<Cliente>();
    }
    
    public void ingresarCliente(Cliente clien){
        listaCliente.add(clien);
    }
    
    public ArrayList<Cliente> listar(){
        return listaCliente;
    }
    
    
    
    
    
    
}
