

package Repositorio;

import Modelo.Venta;
import Modelo.Vehiculo;
import Modelo.Cliente;
import java.util.ArrayList;


public class RepositorioVentas {
    
    private ArrayList<Venta> listaVentas;

    public RepositorioVentas() {
        listaVentas = new ArrayList<Venta>();
    }
    
    public void ventaRealizada(){
        
    }
    
    
    
    
    
    
    
    
    
}
