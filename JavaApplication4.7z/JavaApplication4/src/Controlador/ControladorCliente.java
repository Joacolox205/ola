
package Controlador;

import Modelo.Cliente;
import Repositorio.RepositerioCliente;
import java.util.ArrayList;

public class ControladorCliente {
    
    private RepositerioCliente repoClin;

    public ControladorCliente() {
        repoClin = new RepositerioCliente();
    }
    
    public void registrarCliente(String rut, String nombres, String apellidos, String telefono, String correoElectonico){
        Cliente cliente = new Cliente (rut, nombres, apellidos, telefono, correoElectonico);
        repoClin.ingresarCliente(cliente);
    }
    
    public ArrayList<Cliente> obtenerCliente(){
        return repoClin.listar();
    }
    
    
    
    
    
    
    
    
    
}
