
package PanelPrincipal;

import vista.FromCliente;

public class Main {
    
    FromCliente vista = new FromCliente();
    vista.setVisible(true);
    
    
    
    
    
}
