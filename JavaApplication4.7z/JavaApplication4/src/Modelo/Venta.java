
package Modelo;


public class Venta {
    
    private String fechaVenta;
    private int valorVenta;

    public Venta(String fechaVenta, int valorVenta) {
        this.fechaVenta = fechaVenta;
        this.valorVenta = valorVenta;
    }

    public int getValorVenta() {
        return valorVenta;
    }

    public void setValorVenta(int valorVenta) {
        this.valorVenta = valorVenta;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }
    
    
    
    
    
    
    
}
