package main;



import controlador.ControladorCanciones;
import modelo.CantanteDAO;
import vista.VistaCancion;

public class Sistema {

    public static void main(String[] args) {
        
        
        VistaCancion vista = new VistaCancion();
        
        
        CantanteDAO DAO = new DAO();
        
        
        ControladorCanciones controlador = new ControladorCanciones(vista, DAO);
        
        
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
}