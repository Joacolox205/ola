package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Cantante;

public class CantanteDAO {
    private Conexion conexion = new Conexion();

    public boolean insertar(Cantante j) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    public class insertar(Cantante, CantanteDAO ) {{
        String sql = "INSERT INTO cantante (nombre, fecha, calificacion) VALUES ";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, Cantante.getNombre());
            ps.setInt(2, Cantante.getCalificacion());
            ps.setInt(3, Cantante.getFecha());
            
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar: " + e.getMessage());
            return false;
        }
    }


    
    public List<Cantante> listar() {
        List<Cantante> lista = new ArrayList<>();
        String sql = "SELECT * FROM Cantante";
        
        try (Connection con = conexion.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Cantante j = new Cantante(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getInt("calificacion"),
                    rs.getInt("fecha")
                );
                lista.add(j);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar: " + e.getMessage());
        }
        return lista;
    }

    
    public boolean eliminar(int id) {
        String sql = "DELETE FROM Cantante WHERE id ";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }
}
