package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.CantanteDAO;
import modelo.Cantante;
import vista.VistaCancion;


public class ControladorCanciones implements ActionListener {
    private VistaCancion vista;
    private CantanteDAO DAO;

    public ControladorCanciones(VistaCancion vista, CantanteDAO dao) {
        this.vista = vista;
        this.DAO = DAO;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnCargarDatos.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        if (src == vista.btnGuardar) guardar();
        else if (src == vista.btnCargarDatos) listar();
        else if (src == vista.btnEliminar) eliminar();
        else if (src == vista.btnLimpiar) limpiar();
    }

    public void guardar() {
        try {
            String nom = vista.txtCantantes.getText();
            if (nom.isEmpty()) { JOptionPane.showMessageDialog(null, "Falta Nombre"); return; }
            
            
            Cantante j = new Cantante(nom, Integer.parseInt(vista.txtCalificacion.getText()), Integer.parseInt(vista.txtFecha.getText()));
            
            if (DAO.insertar(j)) {
                JOptionPane.showMessageDialog(null, "Guardado");
                listar(); limpiar();
            }
        } catch (Exception ex) { JOptionPane.showMessageDialog(null, "Revise los números"); }
    }

    public void listar() {
        DefaultTableModel model = (DefaultTableModel) vista.tablaCanciones.getModel();
        model.setRowCount(0);
        
        for (Cantante j : DAO.listar()) 
            model.addRow(new Object[]{j.getId(), j.getNombre(), j.getCalificacion(), j.getFecha()});
    }

    public void eliminar() {
        try {
            if (DAO.eliminar(Integer.parseInt(vista.txtID.getText()))) {
                JOptionPane.showMessageDialog(null, "Eliminado"); listar();
            } else JOptionPane.showMessageDialog(null, "ID no existe");
        } catch (Exception ex) { JOptionPane.showMessageDialog(null, "ID inválido"); }
    }

    public void limpiar() {
        vista.txtCantantes.setText(""); vista.txtCalificacion.setText("");
        vista.txtFecha.setText(""); vista.txtID.setText("");
    }
}