/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.List;
import modelo.Deber;
import modelo.DeberDAO;

import excepciones.DeberException;

/**
 *
 * @author nikom
 */
public class DeberControlador {

    private DeberDAO deberDao;
    
    public DeberControlador(){
        this.deberDao = new DeberDAO();
    }
    
    public List<Deber> listarDeberes() throws DeberException {
        
        List<Deber> deberes = deberDao.listaDeber();
        
        if(deberes.isEmpty()){
            throw new DeberException("No se encontraron deberes guardados");
        }
        
        return deberes;
    }
    
    
    public Deber buscarDeberPorId(int id){
        return deberDao.buscarDeberPorId(id);
    }
    
    public boolean crearDeber(String nombre,String descripcion) throws DeberException{
        
        //1. Vamos a validar los datos
        validarDatosDeber(nombre, descripcion);
        
        //2. Vamos a crear la instancia del nuestro modelo
        Deber deber = new Deber(nombre,descripcion);
        
        //3. Usamos el DAO para guardar
        if(deberDao.guardarDeber(deber)){
            return true;
        }else{
            throw new DeberException("No se pudo guardar el deber en la base de datos");
        }
        
    }
    
    public String actualizarDeber(int id,String nombre,String descripcion,boolean estado){
    
        //1. Creamos el objeto deber con los datos entregados
        Deber deber = new Deber(id,nombre,descripcion,estado);
        
        //2.Usamos elDAO para actualizar el deber
        if(deberDao.actualizarDeber(deber)){
            return "Deber actualizado satisfactoriamente";
        }else{
            return "No se pudo actualizar el deber";
        }        
    }
    
    private void validarDatosDeber(String nombre,String descripcion) throws DeberException{
        if(nombre == null || nombre.trim().isEmpty()){
            throw new DeberException("El nombre del deber no puede estar vacio");
        }
        
        if(descripcion == null || descripcion.trim().isEmpty()){
            throw new DeberException("La descripcion del deber no puede estar vacia");
        }
        
        if(nombre.length() > 100){
            throw new DeberException("El nombre del deber no puede tener mas de 100 caracteres");
        }
        
        if(descripcion.length() > 300){
            throw new DeberException("La descripcion del deber no puede tener mas de 300 caracteres");
        }
    }
    
}

