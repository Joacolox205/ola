/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author nikom
 */
public class DeberDAO {
    
    public boolean guardarDeber(Deber deber){
        
        Connection connection = null;
        PreparedStatement ps = null;
        
        try{        
            connection = Conexion.getConnection();//Conexion esta abierta
            String sql = "INSERT INTO deber(nombre,descripcion,estado) VALUES(?,?,?)";
            
            ps = connection.prepareCall(sql);
            ps.setString(1, deber.getNombre());
            ps.setString(2, deber.getDescripcion());
            ps.setBoolean(3, deber.getEstado() != null ? deber.getEstado() : true);
            
            int resultado = ps.executeUpdate();
                       
            return resultado > 0;
            
        }catch(SQLException ex){
            System.out.println("Error al guardar: " + ex.getMessage());
            
            return false;
        } finally {
            cerrarRecursos(connection, ps, null);
        }
        
    }
    
    
    public List<Deber> listaDeber(){
        
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Deber> deberes = new ArrayList<>();
        
        try{
            
            connection = Conexion.getConnection();
            String sql = "SELECT * FROM deber";
            
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();//Obtiene todos los datos
            
            //Pasarle a cada uno de los elementos de mi array cada uno
            // de los elementos de mi resultSet
            while(rs.next()){//Hay algo mas ? 
                Deber deber = new Deber(
                   rs.getInt("id"),
                   rs.getString("nombre"),
                   rs.getString("descripcion"),
                   rs.getBoolean("estado")
                );
                deberes.add(deber);
            }
            
        }catch(SQLException ex){
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos(connection, ps, rs);
        }
                
        return deberes;
        
    }
    
    
    public Deber buscarDeberPorId(int id){
        
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Deber deber = null;
        
        try{
            
            connection = Conexion.getConnection();
            String sql = "SELECT * FROM deber WHERE id = ?";
            
            ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            if(rs.next()){
                deber = new Deber();
                deber.setId(rs.getInt("id"));
                deber.setNombre(rs.getString("nombre"));
                deber.setDescripcion(rs.getString("descripcion"));
                deber.setEstado(rs.getBoolean("estado"));
            }
        
            
        }catch(SQLException ex){
            System.out.println("Error al buscar : " + ex.getMessage());
        }finally {
            cerrarRecursos(connection, ps, rs);
        }
        
        return deber;
    }
    
    
    public boolean actualizarDeber(Deber deber){
    
        Connection connection = null;
        PreparedStatement ps = null;
        
        try{
            connection = Conexion.getConnection();
            String sql = "UPDATE deber SET nombre = ?, descripcion = ?,estado = ? WHERE id = ?";
            
            ps = connection.prepareStatement(sql);
            ps.setString(1,deber.getNombre());
            ps.setString(2,deber.getDescripcion());
            ps.setBoolean(3,deber.getEstado());
            ps.setInt(4,deber.getId());
            
            int resultado = ps.executeUpdate();
            return resultado > 0;
        
        }catch(SQLException ex){
            System.out.println("Error al editar el deber: " + ex.getMessage());
            return false;
        } finally {
            cerrarRecursos(connection, ps, null);
        }
    
    }
    
    private void cerrarRecursos(Connection connection,PreparedStatement ps , ResultSet rs){        
        try{
            
            if(rs != null) rs.close();
            if(ps != null) ps.close();            
            if(connection != null && !connection.isClosed()) connection.close();
            
        }catch(SQLException ex){
            System.out.println("Error al cerrar los recursos: " + ex.getMessage());
        }    
    }
}
