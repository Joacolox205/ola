package Main; 

import vista.VistaClientes;

public class ExamenApp {

    public static void main(String[] args) {
        
     

        System.out.println("Iniciando sistema de Gestión de Clientes...");
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaClientes().setVisible(true);
            }
        });
    }
}