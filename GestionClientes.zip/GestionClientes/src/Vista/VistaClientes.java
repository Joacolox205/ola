package vista;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import modelo.Cliente;
import modelo.Colecciones;

public class VistaClientes extends JFrame {

    private JTextField txtRut, txtNombres, txtApellidos, txtTel, txtCorreo;
    private JTextArea areaListado;

    public VistaClientes() {
        setTitle("Gestión de Clientes - Examen Final");
        setSize(750, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        
        JLabel lblTitulo = new JLabel("Clientes");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setBounds(0, 0, 750, 40);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setOpaque(true);
        lblTitulo.setBackground(new Color(200, 200, 255));
        add(lblTitulo);

        // Formulario
        int y = 60;
        txtRut = addCampo(30, y, "RUT:");
        txtNombres = addCampo(30, y+=40, "Nombres:");
        txtApellidos = addCampo(30, y+=40, "Apellidos:");
        txtTel = addCampo(30, y+=40, "Teléfono:");
        txtCorreo = addCampo(30, y+=40, "Correo:");

        // Área de Texto
        areaListado = new JTextArea();
        areaListado.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaListado);
        scroll.setBounds(350, 60, 350, 200);
        add(scroll);

        // --- BOTONES ---
        // Reorganicé las coordenadas para que quepan 5 botones
        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(30, 300, 100, 30);
        add(btnLimpiar);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(140, 300, 100, 30);
        add(btnAgregar);

        // BOTÓN NUEVO
        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(250, 300, 100, 30);
        btnEliminar.setBackground(new Color(255, 200, 200)); // Rojo suave
        add(btnEliminar);

        JButton btnMostrar = new JButton("Mostrar");
        btnMostrar.setBounds(400, 300, 100, 30);
        add(btnMostrar);
        
        JButton btnSalir = new JButton("Salir");
        btnSalir.setBounds(550, 300, 100, 30);
        add(btnSalir);

        // --- LÓGICA DE LOS BOTONES ---

        // 1. Agregar
        btnAgregar.addActionListener(e -> {
            if(txtRut.getText().isEmpty() || txtNombres.getText().isEmpty()){
                JOptionPane.showMessageDialog(this, "Ingrese al menos RUT y Nombre");
                return;
            }
            String nombreCompleto = txtNombres.getText() + " " + txtApellidos.getText();
            Colecciones.agregarCliente(new Cliente(txtRut.getText(), nombreCompleto, txtTel.getText(), txtCorreo.getText()));
            JOptionPane.showMessageDialog(this, "Cliente Agregado!");
            limpiar();
        });

        // 2. Eliminar (NUEVO)
        btnEliminar.addActionListener(e -> {
            String rut = txtRut.getText();
            if (rut.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Escriba el RUT del cliente a eliminar en la casilla RUT.");
                return;
            }
            
            boolean eliminado = Colecciones.eliminarCliente(rut);
            
            if (eliminado) {
                JOptionPane.showMessageDialog(this, "Cliente eliminado exitosamente.");
                areaListado.setText(Colecciones.listadoClientes()); // Actualizar la lista visual
                limpiar();
            } else {
                JOptionPane.showMessageDialog(this, "Error: RUT no encontrado.");
            }
        });

        // 3. Mostrar
        btnMostrar.addActionListener(e -> {
            areaListado.setText(Colecciones.listadoClientes());
        });

        // 4. Limpiar
        btnLimpiar.addActionListener(e -> limpiar());
        
        // 5. Salir
        btnSalir.addActionListener(e -> dispose());
    }

    private JTextField addCampo(int x, int y, String titulo) {
        JLabel lbl = new JLabel(titulo);
        lbl.setBounds(x, y, 80, 25);
        add(lbl);
        JTextField txt = new JTextField();
        txt.setBounds(x + 80, y, 200, 25);
        add(txt);
        return txt;
    }
    
    private void limpiar(){
        txtRut.setText(""); txtNombres.setText(""); txtApellidos.setText("");
        txtTel.setText(""); txtCorreo.setText("");
    }
}
