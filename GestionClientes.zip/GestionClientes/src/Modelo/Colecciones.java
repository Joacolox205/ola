package modelo;
import java.util.ArrayList;

public class Colecciones {
    public static ArrayList<Cliente> listaClientes = new ArrayList<>();
    public static ArrayList<Vehiculo> listaVehiculos = new ArrayList<>();
    public static ArrayList<Venta> listaVentas = new ArrayList<>();

    
    public static void agregarCliente(Cliente c) { listaClientes.add(c); }
    public static void agregarVehiculo(Vehiculo v) { listaVehiculos.add(v); }
    public static void agregarVenta(Venta v) { listaVentas.add(v); }

    
    public static boolean eliminarCliente(String rut) {
       
        return listaClientes.removeIf(c -> c.getRut().equalsIgnoreCase(rut));
    }

    
    public static String listadoClientes() {
        if (listaClientes.isEmpty()) return "No hay clientes registrados.";
        String s = "";
        for(Cliente c : listaClientes) s += c.toString() + "\n";
        return s;
    }
    
    public static String listadoVehiculos() {
        String s = "";
        for(Vehiculo v : listaVehiculos) s += v.toString() + "\n";
        return s;
    }
    
    public static String listadoVentas() {
        String s = "";
        for(Venta v : listaVentas) s += v.toString() + "\n-----------------\n";
        return s;
    }
}
