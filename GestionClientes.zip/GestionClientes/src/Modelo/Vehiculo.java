package modelo;

public abstract class Vehiculo {
    protected String patente;
    protected String marca;
    protected String modelo;
    protected int kilometraje;

    public Vehiculo(String patente, String marca, String modelo, int kilometraje) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometraje = kilometraje;
    }

    @Override
    public String toString() {
        return "Patente: " + patente + " | " + marca + " " + modelo + " | " + kilometraje + "km";
    }
}
