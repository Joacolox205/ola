package modelo;

public class Cliente {
    private String rut;
    private String nombreCompleto;
    private String telefono;
    private String correo;

    public Cliente(String rut, String nombreCompleto, String telefono, String correo) {
        this.rut = rut;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.correo = correo;
    }

    
    public String getRut() { return rut; }
    public String getNombreCompleto() { return nombreCompleto; }

    @Override
    public String toString() {
        return rut + " | " + nombreCompleto + " | " + telefono + " | " + correo;
    }
}
