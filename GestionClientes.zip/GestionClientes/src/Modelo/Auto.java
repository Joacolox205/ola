package modelo;

public class Auto extends Vehiculo {
    private String tipoEnergia;
    private String aireAcon;

    public Auto(String patente, String marca, String modelo, int kilometraje, String tipoEnergia, String aireAcon) {
        super(patente, marca, modelo, kilometraje);
        this.tipoEnergia = tipoEnergia;
        this.aireAcon = aireAcon;
    }

    @Override
    public String toString() {
        return "[AUTO] " + super.toString() + " | Energía: " + tipoEnergia + " | A/C: " + aireAcon;
    }
}
