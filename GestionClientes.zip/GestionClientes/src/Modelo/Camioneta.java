package modelo;

public class Camioneta extends Vehiculo {
    private double capacidadCarga;

    public Camioneta(String patente, String marca, String modelo, int kilometraje, double capacidadCarga) {
        super(patente, marca, modelo, kilometraje);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public String toString() {
        return "[CAMIONETA] " + super.toString() + " | Carga: " + capacidadCarga + "kg";
    }
}