package modelo;

public class Venta {
    private String fecha;
    private Cliente cliente;
    private Vehiculo vehiculo;
    private int valor;

    public Venta(String fecha, Cliente cliente, Vehiculo vehiculo, int valor) {
        this.fecha = fecha;
        this.cliente = cliente;
        this.vehiculo = vehiculo;
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "VENTA [" + fecha + "] $" + valor + "\n -> " + cliente.toString() + "\n -> " + vehiculo.toString();
    }
}
