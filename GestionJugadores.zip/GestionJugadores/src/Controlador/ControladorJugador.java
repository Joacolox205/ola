package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Jugador;
import modelo.JugadorDAO;
import vista.VistaJugador;

public class ControladorJugador implements ActionListener {
    private VistaJugador vista;
    private JugadorDAO dao;

    public ControladorJugador(VistaJugador vista, JugadorDAO dao) {
        this.vista = vista;
        this.dao = dao;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnListar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        if (src == vista.btnGuardar) guardar();
        else if (src == vista.btnListar) listar();
        else if (src == vista.btnEliminar) eliminar();
        else if (src == vista.btnLimpiar) limpiar();
    }

    public void guardar() {
        try {
            String nom = vista.txtNombre.getText();
            if (nom.isEmpty()) { JOptionPane.showMessageDialog(null, "Falta Nombre"); return; }
            
            // Crea objeto y lo manda a guardar en la misma línea
            Jugador j = new Jugador(nom, Integer.parseInt(vista.txtCosto.getText()), Integer.parseInt(vista.txtPartidos.getText()));
            
            if (dao.insertar(j)) {
                JOptionPane.showMessageDialog(null, "Guardado");
                listar(); limpiar();
            }
        } catch (Exception ex) { JOptionPane.showMessageDialog(null, "Revise los números"); }
    }

    public void listar() {
        DefaultTableModel model = (DefaultTableModel) vista.tablaJugadores.getModel();
        model.setRowCount(0);
        // Recorre y agrega en una sola línea
        for (Jugador j : dao.listar()) 
            model.addRow(new Object[]{j.getId(), j.getNombre(), j.getCostoFichaje(), j.getCantidadPartidos()});
    }

    public void eliminar() {
        try {
            if (dao.eliminar(Integer.parseInt(vista.txtId.getText()))) {
                JOptionPane.showMessageDialog(null, "Eliminado"); listar();
            } else JOptionPane.showMessageDialog(null, "ID no existe");
        } catch (Exception ex) { JOptionPane.showMessageDialog(null, "ID inválido"); }
    }

    public void limpiar() {
        vista.txtNombre.setText(""); vista.txtCosto.setText("");
        vista.txtPartidos.setText(""); vista.txtId.setText("");
    }
}