package main; // <--- OJO: Si esta línea te sale en rojo, haz clic en la bombilla y dale a "Change package"

import controlador.ControladorJugador;
import modelo.JugadorDAO;
import vista.VistaJugador;

public class Sistema {

    public static void main(String[] args) {
        
        // 1. Instanciar Vista
        VistaJugador vista = new VistaJugador();
        
        // 2. Instanciar DAO
        JugadorDAO dao = new JugadorDAO();
        
        // 3. Instanciar Controlador
        ControladorJugador controlador = new ControladorJugador(vista, dao);
        
        // 4. Mostrar ventana
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
}