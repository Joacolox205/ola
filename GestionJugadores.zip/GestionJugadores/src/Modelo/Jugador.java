package modelo;

public class Jugador {
    private int id; // Se agrega ID (aunque no se ingrese, se recupera al listar)
    private String nombre;
    private int costoFichaje;
    private int cantidadPartidos;

    // Constructor vacío
    public Jugador() {
    }

    // Constructor para Insertar (SIN ID, porque es auto-incrementable)
    public Jugador(String nombre, int costoFichaje, int cantidadPartidos) {
        this.nombre = nombre;
        this.costoFichaje = costoFichaje;
        this.cantidadPartidos = cantidadPartidos;
    }

    // Constructor completo (Para Listar desde la BD)
    public Jugador(int id, String nombre, int costoFichaje, int cantidadPartidos) {
        this.id = id;
        this.nombre = nombre;
        this.costoFichaje = costoFichaje;
        this.cantidadPartidos = cantidadPartidos;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getCostoFichaje() { return costoFichaje; }
    public void setCostoFichaje(int costoFichaje) { this.costoFichaje = costoFichaje; }
    public int getCantidadPartidos() { return cantidadPartidos; }
    public void setCantidadPartidos(int cantidadPartidos) { this.cantidadPartidos = cantidadPartidos; }
}
