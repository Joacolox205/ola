package modelo;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    
    // Configuración de la base de datos 'academia'
    private String URL = "jdbc:mysql://localhost:3306/academia"; 
    private String USER = "root";
    private String PASSWORD = "";
    
    public Connection getConexion() {
        Connection conexion = null;
        try {
            // Cargar el driver (A veces necesario en versiones viejas de Java)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a BD Academia");
            
        } catch (Exception error) {
            System.out.println("Error en la Conexión: " + error.getMessage());
        }
        return conexion;
    }
}
