package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JugadorDAO {
    private Conexion conexion = new Conexion();

    // 1. INSERTAR (Nótese que NO ponemos el ID en el INSERT)
    public boolean insertar(Jugador jugador) {
        String sql = "INSERT INTO jugador (nombre, costo_fichaje, cantidad_partidos) VALUES (?, ?, ?)";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, jugador.getNombre());
            ps.setInt(2, jugador.getCostoFichaje());
            ps.setInt(3, jugador.getCantidadPartidos());
            
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar: " + e.getMessage());
            return false;
        }
    }

    // 2. LISTAR (Aquí SI leemos el ID que generó la BD)
    public List<Jugador> listar() {
        List<Jugador> lista = new ArrayList<>();
        String sql = "SELECT * FROM jugador";
        
        try (Connection con = conexion.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Jugador j = new Jugador(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getInt("costo_fichaje"),
                    rs.getInt("cantidad_partidos")
                );
                lista.add(j);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar: " + e.getMessage());
        }
        return lista;
    }

    // 3. ELIMINAR (Por ID, ya que es la clave única)
    public boolean eliminar(int id) {
        String sql = "DELETE FROM jugador WHERE id = ?";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }
}
