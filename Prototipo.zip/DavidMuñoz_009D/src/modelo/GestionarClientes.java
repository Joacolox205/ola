package modelo;
import java.util.ArrayList;

public class GestionarClientes {
    
    private ArrayList<Cliente> listaClientes;

    public GestionarClientes() {
        listaClientes = new ArrayList<Cliente>();
    }
    
    public void insertarCliente(Cliente cl){
        listaClientes.add(cl);
    }
    
    public ArrayList<Cliente> listar(){
        return listaClientes;
    }
}
