package modelo;
import java.util.ArrayList;

public class GestionarVehiculos {
    
    private ArrayList<Vehiculo> listaVehiculos;

    public GestionarVehiculos() {
        listaVehiculos = new ArrayList<Vehiculo>();
    }
    
    public void insertarVehiculo(Vehiculo vehi){
        listaVehiculos.add(vehi);
    }
    
    public ArrayList<Vehiculo> listar(){
        return listaVehiculos;
    }
}
