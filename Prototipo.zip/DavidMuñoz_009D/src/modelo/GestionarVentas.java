package modelo;
import java.util.ArrayList;

public class GestionarVentas {
    
    private ArrayList<Venta> listaVentas;

    public GestionarVentas() {
        listaVentas = new ArrayList<Venta>();
    }
    
    public void insertarVenta(Venta ven){
        listaVentas.add(ven);
    }
    
    public ArrayList<Venta> listar(){
        return listaVentas;
    }
}
