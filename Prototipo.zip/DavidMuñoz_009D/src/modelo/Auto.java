package modelo;

public class Auto extends Vehiculo{
    
    protected String tipoEnergia;
    protected String aireAcon;

    public Auto() {
    }

    public Auto(String tipoEnergia, String aireAcon) {
        this.tipoEnergia = tipoEnergia;
        this.aireAcon = aireAcon;
    }

    public String getTipoEnergia() {
        return tipoEnergia;
    }

    public void setTipoEnergia(String tipoEnergia) {
        this.tipoEnergia = tipoEnergia;
    }

    public String getAireAcon() {
        return aireAcon;
    }

    public void setAireAcon(String aireAcon) {
        this.aireAcon = aireAcon;
    }
    
    
}
