package modelo;

public class Camioneta extends Vehiculo{
    
    protected double capacidad;

    public Camioneta() {
    }

    public Camioneta(double capacidad) {
        this.capacidad = capacidad;
    }

    public double getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(double capacidad) {
        this.capacidad = capacidad;
    }
}
