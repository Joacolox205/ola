package modelo;

public class Venta {
    
    private String fechaVenta;
    private Cliente cliente;
    private Vehiculo vehiculo;
    private String valorVenta;

    public Venta() {
    }

    public Venta(String fechaVenta, Cliente cliente, Vehiculo vehiculo, String valorVenta) {
        this.fechaVenta = fechaVenta;
        this.cliente = cliente;
        this.vehiculo = vehiculo;
        this.valorVenta = valorVenta;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public String getValorVenta() {
        return valorVenta;
    }

    public void setValorVenta(String valorVenta) {
        this.valorVenta = valorVenta;
    }
    
    
    
}
