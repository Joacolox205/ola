package controlador;

import java.util.ArrayList;
import modelo.Auto;
import modelo.Camioneta;
import modelo.GestionarVehiculos;
import modelo.Vehiculo;

public class ControladorVehiculo {
    
    private GestionarVehiculos gestion;

    public ControladorVehiculo() {
        gestion = new GestionarVehiculos();
    }
    
    public void registrarVehiculo(String patente, String marca, String modelo, int kilometraje, String tipoEnergia, String aireAcon, double capacidad){
        Vehiculo vehi = new Vehiculo(patente,marca,modelo,kilometraje) {
            Auto auto = new Auto(tipoEnergia, aireAcon);
            Camioneta cam = new Camioneta(capacidad);
        };
        gestion.insertarVehiculo(vehi);
    }
    
    public ArrayList<Vehiculo> obtenerVehiculos(){
        return gestion.listar();
    }
}
