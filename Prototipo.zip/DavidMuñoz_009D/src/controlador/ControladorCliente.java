package controlador;
import java.util.ArrayList;
import modelo.Cliente;
import modelo.GestionarClientes;

public class ControladorCliente {
    
    private GestionarClientes gestion;
    
    public ControladorCliente(){
        gestion = new GestionarClientes();
    }
    
    public void registrarCliente(String rut, String nombreCompleto, int telefono, String correo){
        Cliente cl = new Cliente(rut,nombreCompleto,telefono,correo);
        gestion.insertarCliente(cl);
    }
    
    public ArrayList<Cliente> obtenerClientes(){
        return gestion.listar();
    }
}
