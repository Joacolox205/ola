package controlador;

import java.util.ArrayList;
import modelo.Cliente;
import modelo.GestionarVentas;
import modelo.Vehiculo;
import modelo.Venta;

public class ControladorVentas {
    
    private GestionarVentas gestion;

    public ControladorVentas() {
        gestion = new GestionarVentas();
    }
    
    public void registrarVentas(String fechaVenta, Cliente cliente, Vehiculo vehiculo, String valorVenta){
        Venta ven = new Venta(fechaVenta,cliente,vehiculo,valorVenta);
        gestion.insertarVenta(ven);
    }
    
    public ArrayList<Venta> obtenerVentas(){
        return gestion.listar();
    }
}
