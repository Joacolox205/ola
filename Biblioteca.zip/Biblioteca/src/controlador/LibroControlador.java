/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import excepciones.LibroException;
import modelo.Libro;
import modelo.LibrosDAO;

import java.util.List;

/**
 *
 * @author nikom
 */
public class LibroControlador {
    
    private LibrosDAO librosDAO;
    
    public LibroControlador(){
        this.librosDAO = new LibrosDAO();
    }
    
    //Metodo para guardar un libro
    public void guardarLibro(String isbn,String titulo,String autor,String editorial)throws LibroException{
        //Vamos a validar
        validacionesLibros(isbn, titulo, autor, editorial);
        
        //Vamos a crear el objeto a guardar
        Libro libro = new Libro(isbn, titulo, autor, editorial);    
        
        //Guardar el libro
        librosDAO.agregarLibro(libro);
    }
    
    public boolean actualizarLibro(String isbn,String titulo,String autor,String editorial)throws LibroException{
        
        //Primero vamos a buscar si es que el libro existe
        Libro libroExistente = librosDAO.buscarLibroPorIsbn(isbn);
        
        if(libroExistente == null){
            throw new LibroException("Libro no encontrado");
        }
        
        Libro libroActualizado = new Libro(isbn, titulo, autor, editorial);
        libroActualizado.setDisponible(libroExistente.isDisponible());
        
        boolean exito = librosDAO.actualizarLibro(isbn, libroActualizado);
        
        if (exito) {
            return true;
        }else{
            return false;
        }            
    }
    
    //Metodo para obtener todos los libros
    public List<Libro> obtenerTodosLosLibros(){
        return librosDAO.getLibros();
    }
    
    public boolean eliminarLibro(String isbn) throws LibroException{
        
        boolean exito = librosDAO.eliminarLibro(isbn);
        if(exito){
            return true;
        }else{
            return false;
        }
        
    }
    
    public Libro buscarLibroPorId(String isbn){
        return librosDAO.buscarLibroPorIsbn(isbn);
    }
    
    private void validacionesLibros(String isbn,String titulo,String autor,String editorial) throws LibroException {
        
        //Validaciones
        if(isbn == null || isbn.trim().isEmpty()){
            throw new LibroException("El isbn no puede estar vacio");
        }
        
        if(titulo == null || titulo.trim().isEmpty()){
            throw new LibroException("El titulo no puede estar vacio");
        }
        
        if(autor == null || autor.trim().isEmpty()){
            throw new LibroException("El autor no puede estar vacio");
        }
        
        if(editorial == null || editorial.trim().isEmpty()){
            throw new LibroException("La editorial no puede estar vacia");
        }        
    }
    
}
