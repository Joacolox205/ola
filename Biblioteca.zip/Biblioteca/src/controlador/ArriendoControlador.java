/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.List;

import modelo.*;
import excepciones.ArriendoException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;        
import java.time.format.DateTimeParseException;

/**
 *
 * @author nikom
 */
public class ArriendoControlador {
    
    
    private ArriendoDAO arriendoDAO;
    private LibrosDAO libroDAO;
    private ClienteDAO clienteDAO;
    
    public ArriendoControlador(){
        arriendoDAO = new ArriendoDAO();
        libroDAO = new LibrosDAO();
        clienteDAO = new ClienteDAO();
    }
    
    public void agregarArriendo(String rutCliente,String isbnLibro , 
            String fechaArriendoStr,String fechaDevolucionStr,String valorArriendoStr) throws ArriendoException{
        
        validarDatosArriendo(rutCliente, 
                isbnLibro, 
                fechaArriendoStr, 
                fechaDevolucionStr, 
                valorArriendoStr);
        
        //1 Validacion el cliente
        Cliente cliente = clienteDAO.buscarClientePorRut(rutCliente);
        if(cliente == null){
            throw new ArriendoException("Cliente no existe en nuestros registros");
        }
        
        //2.Validar el libro
        Libro libro = libroDAO.buscarLibroPorIsbn(isbnLibro);
        if(libro == null){
            throw new ArriendoException("El libro no existe ne nuestro stock");
        }
        
        //Parsear las fechas
        LocalDate fechaArriendo;
        LocalDate fechaDevolucion;
        
        try{
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            fechaArriendo = LocalDate.parse(fechaArriendoStr,formatter);
            fechaDevolucion = LocalDate.parse(fechaDevolucionStr,formatter);
            
            if(fechaDevolucion.isBefore(fechaArriendo)){
                throw new ArriendoException("La fecha de devolucion debe ser posterior a la fecha de arriendo");
            }
        
        }catch(DateTimeParseException ex){
            throw new ArriendoException("Formato de fecha invalido. Use dd/MMM/yyyy");
        }
        
        // Parsear el valor
        double valor;
        try{
            valor = Double.parseDouble(valorArriendoStr);
            if(valor <= 0){
                throw new ArriendoException("El valor del arriendo debe ser mayor a cero");
            }
        }catch(NumberFormatException ex){
            throw new ArriendoException("Valor del arriendo invalido");
        }
        
        
        //Crerar y agregar el arriendo
        Arriendo arriendo = new Arriendo(rutCliente, isbnLibro, fechaArriendo, fechaDevolucion, valor);
        arriendoDAO.agregarArriendo(arriendo);
        
    }
    
    public List<Arriendo> obtenerTodosLosArriendos(){
        return arriendoDAO.getArriendos();
    }
    
    
    private void validarDatosArriendo(String rutCliente,String isbnLibro , 
            String fechaArriendo,String fechaDevolucion,String valorArriendoStr) throws ArriendoException{
        
        if(rutCliente == null || rutCliente.trim().isEmpty()){
            throw new ArriendoException("Rut del cliente no puede estar vacio");
        }
        
        if(isbnLibro == null || isbnLibro.trim().isEmpty()){
            throw new ArriendoException("El ISBN del libro no puede estar vacio");
        }
        
        if(fechaArriendo == null || fechaArriendo.trim().isEmpty()){
            throw new ArriendoException("La Fecha de Arriendo del libro no puede estar vacio");
        }
        
        if(fechaDevolucion == null || fechaDevolucion.trim().isEmpty()){
            throw new ArriendoException("La Fecha de Devolucion del libro no puede estar vacia");
        }
        
        if(valorArriendoStr == null || valorArriendoStr.trim().isEmpty()){
            throw new ArriendoException("La Fecha de Devolucion del libro no puede estar vacia");
        }
        
    }
    
}
