/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepciones;

/**
 *
 * @author nikom
 */
public class ArriendoException extends Exception{
    
    public ArriendoException(String mensaje){
        super(mensaje);
    }
}
