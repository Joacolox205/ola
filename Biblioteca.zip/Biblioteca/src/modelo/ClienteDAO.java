/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import modelo.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nikom
 */
public class ClienteDAO {
    
    private List<Cliente> clientes;
    
    public ClienteDAO(){
        clientes = new ArrayList<>();
    }
        
    //Metodo para guardar clientes
    public void agregarCliente(Cliente cliente){
        clientes.add(cliente);
    }
    
    //Metodo para buscar un cliente
    public Cliente buscarClientePorRut(String rut){
        for(Cliente cliente : clientes){
            if(cliente.getRut().equals(rut)){
                return cliente;
            }
        }
        return null;
    }
    
    //Metodo para actualizar
    public boolean actualizarCliente(String rut,Cliente clienteActualizado){
        Cliente cliente = buscarClientePorRut(rut);
        if(cliente != null){
            int index = clientes.indexOf(cliente);
            clientes.set(index,clienteActualizado);
            return true;
        }
        return false;
    }
    
    //Metodo para eliminar cliente
    public boolean eliminarCliente(String rut){
        Cliente cliente = buscarClientePorRut(rut);
        if(cliente != null){
            return clientes.remove(cliente);
        }
        return false;
    }
    
    
    //Metodo para mostrar todos los clientes
    public List<Cliente> getClientes(){        
        return new ArrayList<>(clientes);
    }
}
