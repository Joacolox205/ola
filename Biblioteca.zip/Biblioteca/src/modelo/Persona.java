/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author nikom
 */
public abstract class Persona {
    
    protected String rut;
    protected String nombres;
    protected String apellidos;
    
    public Persona(String rut,String nombres,String apellidos){
        this.rut = rut;
        this.nombres = nombres;
        this.apellidos = apellidos;        
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
    //Metodfo abstracto para el polimorfismo
    public abstract String obtenerInformacion();
}
