/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author nikom
 */
public class Arriendo {
    
    private static int contadorId = 1;
    private int id;
    private String rutCliente;
    private String isbnLibro;
    private LocalDate fechaArriendo;
    private LocalDate fechaDevolucion;
    private double valorArriendo;
    
    public Arriendo(String rutCliente,String isbnLibro,LocalDate fechaArriendo,
            LocalDate fechaDevolucion,double valorArriendo){
        this.id = contadorId++;
        this.rutCliente = rutCliente;
        this.isbnLibro = isbnLibro;
        this.fechaArriendo = fechaArriendo;
        this.fechaDevolucion = fechaDevolucion;
        this.valorArriendo = valorArriendo;
    }
    
    public int getId() {
        return id;
    }
    
    public String getRutCliente() {
        return rutCliente;
    }
    
    public void setRutCliente(String rutCliente) {
        this.rutCliente = rutCliente;
    }
    
    public String getIsbnLibro() {
        return isbnLibro;
    }
    
    public void setIsbnLibro(String isbnLibro) {
        this.isbnLibro = isbnLibro;
    }
    
    public LocalDate getFechaArriendo() {
        return fechaArriendo;
    }
    
    public void setFechaArriendo(LocalDate fechaArriendo) {
        this.fechaArriendo = fechaArriendo;
    }
    
    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }
    
    public void setFechaDevolucion(LocalDate fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }
    
    public double getValorArriendo() {
        return valorArriendo;
    }
    
    public void setValorArriendo(double valorArriendo) {
        this.valorArriendo = valorArriendo;
    }
    
    public String getFechaArriendoFormateada(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return fechaArriendo.format(formatter);
    }
    
    public String getFechaDevolucionFormateada(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return fechaDevolucion.format(formatter);
    }
    
    @Override
    public String toString(){
        return "Arriendo ID: " + id + "- Cliente: " + rutCliente + " - Libro: " + isbnLibro;
    }
}
