/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import modelo.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nikom
 */
public class ArriendoDAO {
  
    private List<Arriendo> arriendos;
    private Libro libro;
    
    public ArriendoDAO(){
        arriendos = new ArrayList<>();
        libro = new Libro();
    }
    
    //Metodo para guardar Arriendo
    public void agregarArriendo(Arriendo arriendo){
        arriendos.add(arriendo);
    }
    
    //Obtener todos los arriendo
    public List<Arriendo> getArriendos(){
        return new ArrayList<>(arriendos);
    }
    
    //Buscar arriendo por ID
    public Arriendo buscarArriendoPorId(int id){
        for(Arriendo arriendo : arriendos){
            if(arriendo.getId() == id){
                return arriendo;
            }
        }
        return null;
    }
    
    //Buscar arriendo por nombre
    public Arriendo buscarArriendoPorRutClientre(String rutCliente){
        for(Arriendo arriendo : arriendos){
            if(arriendo.getRutCliente() == rutCliente){
                return arriendo;
            }
        }
        return null;
    }
    
    //Buscar arriendo por ID
    public List<Arriendo> buscarArriendoPorLibro(String isbnLibro){
        List<Arriendo> arriendosLibro = new ArrayList<>();
        for(Arriendo arriendo : arriendos){
            if(arriendo.getIsbnLibro().equals(isbnLibro)){
                arriendosLibro.add(arriendo);
            }
        }
        return arriendosLibro;
    }
 
    
    public boolean devolverLibro(int idArriendo){        
        LibrosDAO librosDAO = new LibrosDAO();
        for(Arriendo arriendo : arriendos){
            if(arriendo.getId() == idArriendo){
                //Marcar el libro como disponible
                Libro nuevoLibro = librosDAO.buscarLibroPorIsbn(arriendo.getIsbnLibro());
                if(libro != null){
                    libro.setDisponible(true);
                }
                return true;
            }
        }
        return false;
    }
    
    //Metodos de reportes
    public double calcularTotalArriendos(){
        double total = 0;
        for(Arriendo arriendo : arriendos){
            total += arriendo.getValorArriendo();
        }
        return total;
    }
    
    public double calcularPromedioArriendos(){
        if(arriendos.isEmpty()) return 0;
        return calcularTotalArriendos() / arriendos.size();
    }
    
    
}
