package tienda_veleros;

import Tienda_Veleros.precioFinal;
import java.util.Scanner;


public class Velero {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opcion =0;
        
        do{
            System.out.println("1.- Ingresar Velero ");
            System.out.println("2.- Mostrar Precio Final ");
            System.out.println("3.- Aplicar Ajuste de Precio");
            System.out.println("4.- Contar Veleros de Crucero");
            System.out.println("5.- salir");
            opcion = input.nextInt();
            
            if (opcion ==1) {
                System.out.println("Ingresar Velero");
                
                System.out.println("Modelo : ");
                String codigo = input.next();
                
                System.out.println("Codigo : ");
                String Codigo = input.next();
                
                System.out.println("canridad de velas: ");
                double modelo = input.nextDouble();
            
                Velero = new Velero (marca, codigo, modelo);
                Velero();
            
            }else if(opcion == 2){
                System.out.println("Mostrar precio final ");
                
                System.out.println("codigo");
                String porcentaje = input.next();
                
                System.out.println("porcentaje");
                double porcentaje = input.nextDouble();
                
                System.out.println("codigo");
                String codigo = input.next();
                
                System.out.println("anio");
                double anio = input.nextDouble();
                
                precioFinal = new precioFinal(porcentaje,codigo, anio) {};
                Ajuste_Precio.class();
                
                
            }else if(opcion ==3){
                System.out.println("Venta Veleros");
                System.out.println("Ingrese los pies del barco");
                double cantidad = input.nextDouble();
                
                Velero venta = new cantidadVelas(cantidad);
                venta.mostrarPrecioFinal();
            } else if (opcion == 4){
                System.out.println("Saliendo del sistema");
            }else {
                System.out.println("Ingrese una opcion valida");
            
            }

        }while (opcion !=4);



    }

    public Velero() {
    }
    
}
