package tienda_veleros;

public interface Promociones {
    
    double calcularTotalAPagar();
    
    void RecibirIncremento();
    

}

