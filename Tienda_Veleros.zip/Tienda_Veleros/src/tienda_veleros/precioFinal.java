package Tienda_Veleros;


public abstract class precioFinal {

    public precioFinal(double porcentaje, String codigo1, double anio) {
    }
    
    protected String codigo;
    protected double marca;
    protected final double tarifaBase = 12.5;

    
    public precioFinal codigo, double marca
        this.codigo = codigo;
        this.marca = marca

    private static class precioFinalg {

        public precioFinalg() {
        }
    }
    }

    public marca
    }
    
    public abstract double calcularprecioFinal();
        this.marca = marca
    }

    public marca
    }
    
    public abstract double calcularprecioFinal();
    
    
}
