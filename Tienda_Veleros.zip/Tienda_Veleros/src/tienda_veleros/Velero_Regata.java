
package tienda_veleros;


public class Velero_Regata extends Velero{
    
    private double eslora;
    private double cantidadVelas;
    private double marca;
    private double modelo;
    private double TipoDeRegata;

    public Velero_Regata(double codigo, double nombre, double marca, double modelo, double preciobase) {
        super(codigo, nombre, marca, modelo, preciobase);
    }

    /**
     *
     * @param eslora
     * @param cantidadVelas
     * @param marca
     * @param modelo
     * @param TipoDeRegata
     * @param codigo
     * @param nombre
     * @param marca
     * @param modelo
     * @param preciobase
     */
   

    
   
    /**
     *
     * @param codigo
     * @param nombre
     * @param marca
     * @param modelo
     * @param preciobase
     */
    
    
}
