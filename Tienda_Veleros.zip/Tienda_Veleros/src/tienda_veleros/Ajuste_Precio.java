package Tienda_Veleros;


public abstract class Ajuste_Precio {
    
    protected String codigo;
    protected double marca;
    protected final double tarifaBase = 12.5;

    public ajustePrecio codigo, double marca
        this.codigo = codigo;
        this.marca = marca
    }

    public marca
    }
    
    public abstract double calcularAjuste_Precio();
        this.marca = marca
    }

    public marca
    }
    
    public abstract double calcularAjuste_Precio();
    
    
}
