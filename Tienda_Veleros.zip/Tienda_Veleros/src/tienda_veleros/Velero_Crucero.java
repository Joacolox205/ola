
package tienda_veleros;

public class Velero_Crucero extends Velero{
    
    private double anioFabricacion;
    private double cantidadVelas;
    private double marca;
    private double modelo;
    private double TipoDeCrucero;

    /**
     *
     * @param anioFabricacion
     * @param cantidadVelas
     * @param marca
     * @param modelo
     * @param TipoDeCrucero
     * @param codigo
     * @param nombre
     * @param marca
     * @param modelo
     * @param preciobase
     */
    

    
    
   
    /**
     *
     * @param codigo
     * @param nombre
     * @param marca
     * @param modelo
     * @param preciobase
     */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public Velero_Crucero(double codigo, double nombre, double marca, double modelo, double preciobase) {
        super(codigo, nombre, marca, modelo, preciobase);
    }

    private Velero_Crucero(double codigo, double nombre, double marca, double modelo, double preciobase) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Velero_Crucero(double codigo, double nombre, double marca, double modelo, double preciobase) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
