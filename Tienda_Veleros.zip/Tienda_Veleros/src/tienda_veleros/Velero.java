
package tienda_veleros;


public class Velero {

    private void mostrarPrecioFinal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static Velero() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class Venta_Velero {

        public Venta_Velero() {
        }
    }


    private Velero() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    protected double codigo;
    protected double nombre;
    protected double marca;
    protected double modelo;
    protected double preciobase;

    /**
     *
     * @param codigo
     * @param nombre
     * @param marca
     * @param modelo
     * @param preciobase
     */
    public Velero(double codigo, double nombre, double marca, double modelo, double preciobase) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.modelo = modelo;
        this.preciobase = preciobase;
    }

    private static class Venta_Velero {

        public Venta_Velero() {
        }
    }
    
}



   
    

