/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.List;

import modelo.*;
import excepciones.ClienteException;

/**
 *
 * @author nikom
 */
public class ClienteControlador {
    
    private ClienteDAO clienteDAO;
    
    
    public ClienteControlador(){
        this.clienteDAO = new ClienteDAO();
    }
    
    //Metodo del controlador para guardar clientes
    public void guardarCliente(String rut , String nombres , String apellidos , 
            String fono , String email )throws ClienteException{
    
        //1. Vamos a validar los datos
        validarDatosCliente(rut, nombres, apellidos, fono, email);
        
        //2. Vamos a crear el objeto
        Cliente cliente = new Cliente(rut, nombres, apellidos, fono, email);
        
        //3. Guardamos
        clienteDAO.agregarCliente(cliente);
    }
    
    
    //Método del controlador para listar clientes
    public List<Cliente> obtenerTodosLosClientes(){
        return clienteDAO.getClientes();
    }
    
    private void validarDatosCliente(String rut , String nombres , String apellidos , 
            String fono , String email) throws ClienteException{
    
        if(rut == null || rut.trim().isEmpty()){
            throw new ClienteException("El rut no puede ir vacio");
        }
        if(nombres == null || nombres.trim().isEmpty()){
            throw new ClienteException("El nombre no puede ir vacio");
        }
        if(apellidos == null || apellidos.trim().isEmpty()){
            throw new ClienteException("El apellido no puede ir vacio");
        }
        if(fono == null || fono.trim().isEmpty()){
            throw new ClienteException("El fono no puede ir vacio");
        }
        if(email == null || email.trim().isEmpty()){
            throw new ClienteException("El email no puede ir vacio");
        }
                  
    }
}
