/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author nikom
 */
public class Cliente extends Persona{
    
    private String fono;
    private String email;
    
    public Cliente(String rut,String nombres,String apellidos,String fono,String email){
        super(rut,nombres,apellidos);
        this.fono = fono;
        this.email = email;
    }

    public String getFono() {
        return fono;
    }

    public void setFono(String fono) {
        this.fono = fono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    //Implementamos el metodo abstracto ( polimorfismo ) 
    @Override
    public String obtenerInformacion(){
        return "Cliente: " + nombres + " " + apellidos + " (RUT: " + rut + ")"; 
    }
    
    @Override
    public String toString(){        
       return "Cliente : { rut: " + rut + ", nombres: " + nombres 
               + ", apeliidos: " + apellidos + ",fono: " + fono + ",email: "+ email + "}";
    }
}
