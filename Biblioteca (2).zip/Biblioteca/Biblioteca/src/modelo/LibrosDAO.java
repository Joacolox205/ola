/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nikom
 */
public class LibrosDAO {
    
    private List<Libro> libros;
    
    public LibrosDAO(){
        libros = new ArrayList<>();
    }
    
    //Metodo para guardar Libros
    public void agregarLibro(Libro libro){
        libros.add(libro);
    }
    
    //Metodo para buscar un libro
    public Libro buscarLibroPorIsbn(String isbn){
        for(Libro libro : libros){
            if(libro.getIsbn().equals(isbn)){
                return libro;
            }
        }
        return null;
    }
    
    //Metodo para actualizar
    public boolean actualizarLibro(String isbn,Libro libroActualizado){
        Libro libro = buscarLibroPorIsbn(isbn);
        if(libro != null){
            int index = libros.indexOf(libro);
            libros.set(index,libroActualizado);
            return true;
        }
        return false;
    }
    
    //Metodo para eliminar libro
    public boolean eliminarLibro(String isbn){
        Libro libro = buscarLibroPorIsbn(isbn);
        if(libro != null){
            return libros.remove(libro);
        }
        return false;
    }
    
    //Metodo para mostrar todos los libros
    public List<Libro> getLibros(){        
        return new ArrayList<>(libros);
    }
    
    //Metodo para obtener los librosDisponibles
    public List<Libro> getLibrosDisponibles(){
        List<Libro> disponibles = new ArrayList<>();
        for(Libro libro : libros){
            if(libro.isDisponible()){
                disponibles.add(libro);
            }
        }
        return disponibles;
    }
    
    //Metodo para los libros arrendados
    public List<Libro> getLibrosArrendados(){
        List<Libro> arrendados = new ArrayList<>();
        for(Libro libro : libros){
            if(!libro.isDisponible()){
                arrendados.add(libro);
            }
        }
        return arrendados;
    }
    
   
}
